"use client"

import TodoList from "../todo-list"

export default function SyntheticV0PageForDeployment() {
  return <TodoList />
}